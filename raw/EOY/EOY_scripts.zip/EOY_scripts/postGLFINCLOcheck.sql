set head on
set array 1
set linesize 10000
set pagesize 50000
set long 10000
set echo on
set colsep ";"
set trimspool on
SPOOL C:\postGLFINCLOcheck.SPL

DROP TABLE PreEOYcheck;
Create table PreEOYcheck ( CURRENT_YEAR            VARCHAR2(4),
                           CURRENT_CYCLE           VARCHAR2(9),
                           CURRENT_YEAR_START_DATE DATE,
                           CURRENT_YEAR_END_DATE   DATE,
                           NEXT_YEAR               VARCHAR2(4),
						   NEXT_YEAR_START_DATE    DATE,
						   NEXT_YEAR_END_DATE      DATE)
/

select * from PreEOYcheck;

insert into PreEOYcheck 
select TO_CHAR(FC_START_DATE,'YYYY'),Fin_cycle,fc_start_date,fc_end_date,
       To_char(fc_end_date+1,'YYYY'), FC_END_DATE + 1,
	   LAST_DAY(ADD_MONTHS(FC_END_DATE+1,11))
  FROM sttm_fin_cycle
 where fin_cycle in (select distinct current_cycle from sttm_branch where Record_stat='O' and auth_stat='A');

select * from PreEOYcheck;



PROMPT STTM_DATES
select * from sttm_dates ORDER BY BRANCH_CODE;

PROMPT STTM_BRANCH
select BRANCH_CODE,BRANCH_NAME, END_OF_INPUT,CURRENT_CYCLE,CURRENT_PERIOD from sttm_branch ORDER BY BRANCH_CODE;

PROMPT ALL_ACC_ENTRIES
select * from acvws_all_ac_entries 
 where FINANCIAL_CYCLE = (select CURRENT_CYCLE from PreEOYcheck) 
   and period_code = 'FIN'
order by ac_branch
/


PROMPT PROFIT_LOSS_GLS
select profit_acc, loss_acc, count(*) from gltms_glmaster
 where category in ('3','4') and leaf = 'Y'
 group by profit_acc, loss_acc
/

select AC_BRANCH,decode(a.CUST_GL,'A','Customer','G','Internal',a.cust_gl) c,sum(decode(a.drcr_ind,'D' , -1,1)*a.lcy_amount)
  from acvws_all_ac_entries a
 where balance_upd='U' 
   and period_code ='FIN'
   and financial_CYCLE = (select CURRENT_CYCLE from PreEOYcheck)
 group by AC_BRANCH,cust_gl
/

 
PROMPT GLTBS_GL_BAL_FOR_FIN
SELECT b.branch_code,a.gl_code,a.profit_acc, a.loss_acc, b.ccy_code, b.cr_bal_lcy , b.dr_bal_lcy, b.dr_bal , b.cr_bal
  from gltms_glmaster a, gltbs_gl_bal b
 WHERE a.category in ('3','4') 
   AND a.profit_acc <> a.gl_code 
   AND a.loss_acc <> a.gl_code 
   AND a.record_stat = 'O' 
   AND b.gl_code = a.gl_code 
   AND b.fin_year = (select CURRENT_CYCLE from PreEOYcheck) 
   AND b.period_code = 'FIN' AND B.LEAF='Y'
/

PROMPT SUM_FOR_LEAF_ENTRIES_GLTBS_GLBAL_FOR_FIN
SELECT b.branch_code ,sum(b.cr_bal_lcy) ,sum(b.dr_bal_lcy),sum(b.dr_bal) ,sum(b.cr_bal)
  from gltms_glmaster a,gltbs_gl_bal b
 WHERE a.category in ('3','4') 
   AND a.profit_acc <> a.gl_code 
   AND a.loss_acc <> a.gl_code 
   AND a.record_stat = 'O'
   AND b.gl_code = a.gl_code 
   AND b.fin_year = (select CURRENT_CYCLE from PreEOYcheck)
   AND b.period_code = 'FIN' AND B.LEAF='Y' group by branch_code
/

PROMPT SUM_FOR_LEAF_NODE_ENTRIES_GLTBS_GLBAL_FOR_FIN
SELECT b.branch_code ,sum(b.cr_bal_lcy) ,sum(b.dr_bal_lcy),sum(b.dr_bal) ,sum(b.cr_bal)
  from gltms_glmaster a,gltbs_gl_bal b
 WHERE a.category in ('3','4') 
   AND a.profit_acc <> a.gl_code 
   AND a.loss_acc <> a.gl_code 
   AND a.record_stat = 'O' 
   AND b.gl_code = a.gl_code 
   AND b.fin_year = (select CURRENT_CYCLE from PreEOYcheck)
   AND b.period_code = 'FIN' group by branch_code
/

PROMPT SUM_GLTBS_GLBAL
select BRANCH_CODE, SUM(CR_BAL),SUM(CR_BAL_LCY),SUM(DR_BAL), SUM(DR_BAL_LCY)
  from gltbs_gl_bal where period_code ='FIN'
   and fin_year = (select CURRENT_CYCLE from PreEOYcheck)
GROUP BY BRANCH_CODE
/

select BRANCH_CODE, SUM(CR_BAL),SUM(CR_BAL_LCY),SUM(DR_BAL), SUM(DR_BAL_LCY)
  from gltbs_gl_bal where period_code ='FIN'
   and fin_year = (select CURRENT_CYCLE from PreEOYcheck)
 GROUP BY BRANCH_CODE
/

PROMPT FULL_DETAILS
select * from gltbs_gl_bal 
 where category in ('3', '4') 
   and fin_year = (select CURRENT_CYCLE from PreEOYcheck)
   AND LEAF='Y'
   AND period_code = 'FIN'
 order by branch_code , gl_code
/


PROMPT YEAR_MOVEMENT
select * from gltbs_gl_bal 
 where fin_year = (select CURRENT_CYCLE from PreEOYcheck)
 --(select fin_cycle from sttm_fin_cycle where fc_start_date='01-JAN-2013') 
 order by branch_code , gl_code
/
PROMPT FIN PERIOD COUNTS
select count(*) from gltbs_glhistory 
 where fin_year = (select CURRENT_CYCLE from PreEOYcheck)
   and period_code = 'FIN'
/

Select count(*) from gltbs_gl_bal 
 where fin_year = (select CURRENT_CYCLE from PreEOYcheck)
   and period_code = 'FIN'
/

select count(*) from gltbs_misbal 
 where fin_year = (select CURRENT_CYCLE from PreEOYcheck)
   and period_code = 'FIN'
/

select count(*) from gltb_budget_bal 
 where fin_year = (select CURRENT_CYCLE from PreEOYcheck) 
   and period_code = 'FIN'
/

select count(*) from gltbs_misavgbal 
 where fin_year = (select CURRENT_CYCLE from PreEOYcheck)
   and period_code = 'FIN'
/


spool off
