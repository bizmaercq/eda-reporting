set head on
set echo on
set feed on
set linesize 10000
set pagesize 10000
set long 2000
set colsep ';'
set numformat '999999999999999.999'
spool c:\PostEOYcheck.spl

SHOW USER



DROP TABLE PostEOYcheck;
Create table PostEOYcheck ( CURRENT_YEAR            VARCHAR2(4),
                           CURRENT_CYCLE           VARCHAR2(9),
                           CURRENT_YEAR_START_DATE DATE,
                           CURRENT_YEAR_END_DATE   DATE,
                           NEXT_YEAR               VARCHAR2(4),
						   NEXT_YEAR_START_DATE    DATE,
						   NEXT_YEAR_END_DATE      DATE)
/

select * from PostEOYcheck;
  
insert into PostEOYcheck 
select TO_CHAR(FC_START_DATE,'YYYY'),Fin_cycle,fc_start_date,fc_end_date,
       To_char(fc_end_date+1,'YYYY'), FC_END_DATE + 1,
	   LAST_DAY(ADD_MONTHS(FC_END_DATE+1,11))
  FROM sttm_fin_cycle
 where fin_cycle in (select distinct current_cycle from sttm_branch where Record_stat='O' and auth_stat='A');

select * from PostEOYcheck;



prompt sttm_branch
select branch_code,record_stat,auth_stat,current_cycle,current_period,time_level,end_of_input from sttm_branch
order by 1
/

prompt sttm_dates
select * from sttm_dates
/

prompt sttm_aeod_dates
select * from sttm_aeod_dates
/

select ac_branch,financial_cycle,period_code,count(*), 
       sum(decode(drcr_ind,'D',-lcy_amount)) debit_total,
       sum(decode(drcr_ind,'C',lcy_amount)) credit_total,
	   sum(decode(drcr_ind,'D',-lcy_amount,lcy_amount)) balance
  from acvws_all_ac_entries 
 where financial_cycle = (select fin_cycle from sttm_fin_cycle 
                           where fc_start_date = (select NEXT_YEAR_START_DATE from PostEOYcheck))
 group by ac_branch,financial_cycle,period_code
/

spool off