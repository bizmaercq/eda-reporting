set head on
set echo on
set feed on
set linesize 10000
set pagesize 10000
set long 2000
set colsep ';'
set numformat '999999999999999.999'
spool c:\PreEOYcheck.spl

SHOW USER

DROP TABLE PreEOYcheck;
Create table PreEOYcheck ( CURRENT_YEAR            VARCHAR2(4),
                           CURRENT_CYCLE           VARCHAR2(9),
                           CURRENT_YEAR_START_DATE DATE,
                           CURRENT_YEAR_END_DATE   DATE,
                           NEXT_YEAR               VARCHAR2(4),
						   NEXT_YEAR_START_DATE    DATE,
						   NEXT_YEAR_END_DATE      DATE)
/

select * from PreEOYcheck;
  
insert into PreEOYcheck 
select TO_CHAR(FC_START_DATE,'YYYY'),Fin_cycle,fc_start_date,fc_end_date,
       To_char(fc_end_date+1,'YYYY'), FC_END_DATE + 1,
	   LAST_DAY(ADD_MONTHS(FC_END_DATE+1,11))
  FROM sttm_fin_cycle
 where fin_cycle in (select distinct current_cycle from sttm_branch where Record_stat='O' and auth_stat='A');

select * from PreEOYcheck;

select distinct current_cycle from sttm_branch where Record_stat='O' and auth_stat='A'


Prompt Sttm_Branch
SELECT * FROM STTM_BRANCH
/
Prompt Branches where Calendar is NOT maintained for NEXT year
Select Branch_Code From Sttms_Branch a
Where Not Exists (Select * From Sttm_Lcl_Hol_Master 
                   Where Branch_Code = a.Branch_Code 
				     And Record_Stat = 'O' and Auth_stat='A'
					 and Year in (select Next_year from PreEOYcheck))
/

Prompt Holiday Calendar Master sttm_lcl_hol_master for NEXT YEAR
Select * From Sttm_Lcl_Hol_Master Where Year in (select Next_year from PreEOYcheck) And Record_Stat = 'O' And Auth_Stat = 'A'
/

Prompt Holiday Calendar sttm_lcl_holiday for NEXT YEAR
SELECT * FROM sttm_lcl_holiday WHERE Year in (select Next_year from PreEOYcheck)
/

Prompt Transaction Code at Bank Level
select b.trn_code , b.record_stat , b.auth_stat from sttms_bank a, sttms_trn_code b where a.year_end_pnl_trncode = trn_code
/

Prompt Fin Cycle Maintenace - NEXT YEAR
Select * From Sttms_Fin_Cycle Where Fc_Start_Date IN (SELECT NEXT_YEAR_START_DATE FROM PreEOYcheck) And Record_Stat = 'O' And Auth_Stat = 'A'
/

Prompt Period Code Maint for NEXT YEAR
select * from sttms_period_codes 
 where pc_start_date between (SELECT NEXT_YEAR_START_DATE FROM PreEOYcheck) and (SELECT NEXT_YEAR_END_DATE FROM PreEOYcheck)
/

Prompt Period Code Status FOR NEXT YEAR
SELECT branch_code,fin_cycle,count(*) FROM sttb_per_code_status 
 Where fin_cycle = (Select fin_cycle From Sttms_Fin_Cycle
                     Where Fc_Start_Date in (SELECT NEXT_YEAR_START_DATE FROM PreEOYcheck) And Record_Stat = 'O' 
					   And Auth_Stat = 'A') 
group by branch_code,fin_cycle					   
 Order By 1
/

Prompt For CCY Holiday Not Maintained For NEXT YEAR
select * from cytm_ccy_defn where record_stat ='O' and auth_stat='A'
and ccy_code not in
(select CCY from sttm_ccy_holiday where year in (SELECT NEXT_YEAR FROM PreEOYcheck))
/

Prompt For CCY Holiday Calendar Not Maintained For NEXT YEAR
select * from cytm_ccy_defn where record_stat ='O' and auth_stat='A'
and ccy_code not in
(select CCY from sttm_ccy_hol_master where year in (SELECT NEXT_YEAR FROM PreEOYcheck))
/
Prompt Tax Cycle Maint for NEXT YEAR
Select * From Sttm_Tax_Cycle
 Where Tc_Start_Date in (SELECT NEXT_YEAR_START_DATE FROM PreEOYcheck) 
   And Tc_End_Date = (SELECT NEXT_YEAR_END_DATE FROM PreEOYcheck)
   And Record_Stat = 'O' And Auth_Stat = 'A'
/

PROMPT EITM_MODULES_INSTALLED
SELECT * FROM EITM_MODULES_INSTALLED where function_id = 'GLFINCLO' ORDER BY BRANCH_CODE, EOC_GROUP, FUNCTION_ID
/

Prompt user_sequences where sequence_name like '%ZYND%'
select * from user_sequences where sequence_name like '%ZYND%'
/

Prompt gl_period_check
select * from cstb_param where param_name = 'GL_PERIOD_CHECK'
/

Prompt chekcks sequence exists for all branches
SELECT * FROM STTM_BRANCH WHERE BRANCH_CODE
NOT IN(SELECT SUBSTR(SEQUENCE_NAME, 6,3) FROM user_sequences where sequence_name like '%ZYND%')
/

Prompt gltb_gl_bal count for FIN
select count(*),fin_year from gltb_gl_bal 
 where period_code = 'FIN' and fin_year in (select CURRENT_CYCLE FROM PreEOYcheck)
group by fin_year
/

Prompt gltb_misbal count for FIN
select count(*),fin_year from gltb_misbal 
 where period_code = 'FIN' and fin_year in (select CURRENT_CYCLE FROM PreEOYcheck)
group by fin_year
/

Prompt gltb_misavgbal count for FIN
select count(*),fin_year from gltb_misavgbal 
 where period_code = 'FIN' and fin_year in (select CURRENT_CYCLE FROM PreEOYcheck)
group by fin_year
/

Prompt gltb_cust_acc_breakup count for FIN
select count(*),fin_year 
  from gltb_cust_acc_breakup 
 where period_code = 'FIN' and fin_year in (select CURRENT_CYCLE FROM PreEOYcheck)
group by fin_year
/

Prompt gltb_cust_accbreakup count for FIN
select count(*),fin_year from gltb_cust_accbreakup 
 where period_code = 'FIN' and fin_year in (select CURRENT_CYCLE FROM PreEOYcheck)
group by fin_year
/

Prompt getting GL details which does not have Profit and Loss mapped
Select Gl_Code, Gl_Desc
From Gltms_Glmaster
Where Leaf = 'Y' And (Profit_Acc Is Null Or Loss_Acc Is Null) And
Record_Stat = 'O' And Auth_Stat = 'A' And Category In ('3', '4')
/

Prompt checking validity of yearend PL from gltm_glmaster
select a.gl_code,a.gl_desc from gltms_glmaster a where leaf = 'Y' and
(a.PROFIT_ACC is not null or a.LOSS_ACC is not null)
and a.record_stat = 'O' and a.category in ('3','4')
and not exists
(select 1 from gltms_glmaster b where b.leaf = 'Y'
and b.record_stat = 'O'
and b.gl_code = a.profit_acc)
union
select a.gl_code,a.gl_desc from gltms_glmaster a where leaf = 'Y' and
(a.PROFIT_ACC is not null or a.LOSS_ACC is not null)
and a.record_stat = 'O' and a.category in ('3','4')
and not exists
(select 1 from gltms_glmaster b where b.leaf = 'Y'
and b.record_stat = 'O'
and b.gl_code = a.loss_acc)
/


Prompt checking validity of yearend PL from sttb_account
select a.gl_code,a.gl_desc from gltms_glmaster a where leaf = 'Y' and
(a.PROFIT_ACC is not null or a.LOSS_ACC is not null)
and a.record_stat = 'O' and a.category in ('3','4')
and not exists
(select 1 from sttbs_account b
where b.AC_GL_NO = a.profit_acc
and b.AC_OR_GL = 'G'
and b.GL_STAT_BLOCKED = 'N'
and b.AC_GL_REC_STATUS = 'O'
and b.auth_stat = 'A')
union
select a.gl_code,a.gl_desc from gltms_glmaster a where leaf = 'Y' and
(a.PROFIT_ACC is not null or a.LOSS_ACC is not null)
and a.record_stat = 'O' and a.category in ('3','4')
and not exists
(select 1 from sttbs_account b
where b.AC_GL_NO = a.loss_acc
and b.AC_OR_GL = 'G'
and b.GL_STAT_BLOCKED = 'N'
and b.AC_GL_REC_STATUS = 'O'
and b.auth_stat = 'A')
/

spool off