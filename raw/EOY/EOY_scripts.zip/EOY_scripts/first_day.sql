set head on
set echo on
set feed on
set linesize 10000
set pagesize 10000
set long 2000
set colsep ';'
set numformat '999999999999999.999'
spool C:\first_day.spl

SHOW USER



DROP TABLE firstday;
Create table firstday ( CURRENT_YEAR            VARCHAR2(4),
                        CURRENT_CYCLE           VARCHAR2(9),
                        CURRENT_YEAR_START_DATE DATE,
                        CURRENT_YEAR_END_DATE   DATE,
                        PREV_YEAR               VARCHAR2(4),
						PREV_YEAR_START_DATE    DATE,
						PREV_YEAR_END_DATE      DATE)
/

select * from firstday;
  
insert into firstday 
select TO_CHAR(FC_START_DATE,'YYYY'),Fin_cycle,fc_start_date,fc_end_date,
       To_char(fc_start_date-1,'YYYY'), 
     LAST_DAY(ADD_MONTHS(fc_start_date-1,-12))+1 ,fc_start_date - 1
  FROM sttm_fin_cycle
 where fin_cycle in (select distinct current_cycle from sttm_branch where Record_stat='O' and auth_stat='A')

select * from firstday;

PROMPT sttm_branch
select * from sttms_branch order by branch_code
/

PROMPT sttm_dates
select * from sttms_dates order by branch_code
/

PROMPT FIN Balance 
SELECT b.* FROM gltms_glmaster a, gltbs_gl_bal   b
 WHERE a.category 	 IN ('3','4') 
   AND a.profit_acc 	<> a.gl_code 
   AND a.loss_acc 	<> a.gl_code 
   AND a.record_stat 	= 'O' 
   AND a.leaf		= 'Y' 
   AND b.gl_code	= a.gl_code 
   AND b.fin_year	in (select PREV_YEAR from firstday)
   AND b.period_code	= 'FIN'
   AND ((NVL(b.cr_bal_lcy,0) - NVL(b.dr_bal_lcy,0)) <> 0 OR (NVL(b.cr_bal,0) - NVL(b.dr_bal,0)) <> 0)
/

PROMPT JAN Balance for CURRENT YEAR
SELECT  b.*
FROM    gltms_glmaster a, gltbs_gl_bal   b, sttms_branch c
WHERE   a.category 	 IN ('3','4') 
AND     a.profit_acc 	<> a.gl_code 
AND     a.loss_acc 	<> a.gl_code 
AND     a.record_stat 	= 'O' 
AND     a.leaf		= 'Y' 
AND     b.gl_code	= a.gl_code 
AND	c.branch_code	= b.branch_code
AND     b.fin_year	= c.current_cycle
AND     b.period_code	= c.current_period
AND     ((NVL(b.cr_bal_lcy,0) - NVL(b.dr_bal_lcy,0)) <> 0 OR (NVL(b.cr_bal,0) - NVL(b.dr_bal,0)) <> 0)
/

PROMPT actb_daily contributing to gl_bal for CURRENCY YEAR
select ac_branch,ac_no,ac_ccy,financial_cycle,period_code,
sum(decode(drcr_ind,'D',-1,1)*NVL(FCY_AMOUNT,0)) FCY_AMT,
sum(decode(drcr_ind,'D',-1,1)*LCY_AMOUNT) LCY_AMT
from actbs_daily_log
where nvl(delete_stat,'D') <> 'D'
and cust_gl = 'G'
and category in ('3','4')
GROUP BY ac_branch,ac_no,ac_ccy,financial_cycle,period_code
/

PROMPT cstb_param for offline GL and vdbal update
select * from cstb_param order by param_name
/



spool off